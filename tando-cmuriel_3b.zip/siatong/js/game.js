var bounds = 1600;
var score=0, life=3;
var short, stick, keyboard;
var scoreText,tryText,overText;
var game = new Phaser.Game(800, 600, Phaser.CANVAS, '');

PlayGame = function (game) {
};

PlayGame = {
    preload: function(){
        game.load.image("back","img/arrow.png");
        game.load.image("bg","img/bg.png");
        game.load.spritesheet("short","img/short.png",170,167);
        game.load.spritesheet("stick","img/character.png",200,300);
    }, 
    create: function(){
        game.physics.startSystem(Phaser.Physics.ARCADE);
        game.world.setBounds(0,0,bounds,0);

        game.add.sprite(0,0,"bg");
        back = game.add.sprite(13,10,"back");

        short = game.add.sprite(78,220,'short');
        stick = game.add.sprite(220,220,'stick');

        short.animations.add('walk-right',[5,6,7],7,true);
        short.animations.add('walk-left',[0,1,2,3],7,true);

        stick.animations.add('walk-right',[7,8,9,10],7,true);
        stick.animations.add('walk-left',[3,4,5],7,true);
        /*platform1.scale.x = 0.1;
        platform1.scale.y = 6;*/
        game.physics.arcade.enable(stick);
        
        keyboard = game.input.keyboard.createCursorKeys();

        scoreText = game.add.text(560,550,"Score: 0",{font:'32px Ravie', fill:'white'});
        tryText = game.add.text(30,550,"Try: 3",{font:'32px Ravie', fill:'red'});
        overText = game.add.text(10,200,"Game Over Subukan Muli Baka Sakaling Magtagumpay Ka",{font:'20px Ravie', fill:'white'});

        game.camera.follow(stick, Phaser.Camera.FOLLOW_TOPDOWN);

        scoreText.fixedToCamera = true;
        overText.fixedToCamera = true;
        tryText.fixedToCamera = true;
    }, 
    update: function(){
        game.physics.arcade.collide(stick,short);
        //game.physics.arcade.overlap(stick,short,killShort);

        if(keyboard.left.isDown){
                short.body.velocity.x = -500;
                short.animations.play('walk-left');
            }
            else if(keyboard.right.isDown){
                short.body.velocity.x = 500;
                short.animations.play('walk-right');
            }
            else if(keyboard.down.isDown){
                short.body.velocity.y = 500;
            }
            if(keyboard.up.isDown&& player.body.touching.down){
                short.body.velocity.y = -10000;
            }
        },
}

game.state.add('Play', PlayGame, true);
var gamePlay=function(){
    "use strict";
        return{
            /*killShort:function(stick,short){
                score = score + 10;
                scoreText.text = "SCORE: "+score;
                short.kill();
                if(gamePlay.retrieve()<=score){
                    gamePlay.saveScore(score);        
                }
            },*/
        }
}();
