(function() {
	// initialize the framework
	var game = new Phaser.Game(640, 960, Phaser.CANVAS);
	// add game states
	game.state.add('Boot', Syatong.Boot);
	game.state.add('Preloader', Syatong.Preloader);
	game.state.add('MainMenu', Syatong.MainMenu);
	game.state.add('mGame', Syatong.mGame);
		// start the Boot state
	game.state.start('Boot');
	})();