Syatong.MainMenu = function(game){};
Syatong.MainMenu.prototype = {
	create: function(){
		this.music = this.add.audio('whoosh');
		this.add.sprite(0, 0, 'background');
		this.add.button(220,400, 'button-play', this.startGame, this, 1, 0, 2);
	},
	startGame: function() {
		// start the Game state
		this.state.start('mGame'); 
	}
};