var w=800,h=600; 
var bounds= 5000;
var short, stick, lifeText, scoreText, overText, keyboard;
var game = new Phaser.Game(w, h, Phaser.CANVAS, '');

var characterGame=function(){
}
    characterGame.prototype ={
    	preload:function(){
    		//game.load.image('play', 'img/play.png');
    		game.load.image('bg', 'img/bg.png');
    		//game.load.image('home', 'img/home.png');
    		game.load.image('back', 'img/arrow.png');
    		//game.load.spritesheet('short', 'img/short.png');
    		//game.load.spritesheet('stick','img/stick.png');

    		//game.add.audio('bgMusic', 'audio/tic.mp4');
    		//game.add.audio('stickMusic', 'audio/tac.mp4');
    	},
    	create:function(){
    		game.physics.startSystem(Phaser.Physics.ARCADE);

    		game.add.sprite('bg',0,0);
    		game.add.sprite('home',30,60);
    		game.add.sprite('back', 100,250);

    		game.world.setBounds(0,0,bounds,0);

    		short=game.add.sprite(180,350,'short');
    		stick=game.add.sprite(160,300,'stick');

    		short.animations.add('right', [0,1,2,3],7,true);
    		short.animations.add('left', [5,6,7],7,true);

    		stick.animations.add('right', [5,6,7],7,true);
    		stick.animations.add('left', [0,1,2,3],7,true);

    		game.physics.arcade.enable(short);
    		game.physics.arcade.enable(stick);

    		short.body.collideWorldBounds=true;
    		stick.body.collideWorldBounds=true;

    		short.body.bounce.y=1;
    		stick.body.bounce.y=1;

    		short.body.gravity.y=0.5;
    		stick.body.gravity.y=0.5;

    		keyboard=game.input.keyboard.createCursorKeys();

    		scoreText=game.add.text(80,100,'Score:0',{fill:'#ddff00', font:'40px, Ravie', align:'left'});
    		lifeText=game.add.text(70,400,'Life:0', {fill:'white', font:'40px Ravie'});
    		overText=game.add.text(90,200,'Game Over \n Subukan Mong Muli', {fill:'red', font:'60px Magneto'});

    		game.camera.follow(short,Phaser.Camera.FOLLOW_TOPDOWN);
    		game.camera.follow(stick,Phaser.Camera.FOLLOW_TOPDOWN);

    		scoreText.fixedToCamera=true;
    		lifeText.fixedToCamera=true;
    		overText.fixedToCamera=true;
    	},
    	update:function(){
    		game.physics.arcade.collide(stick,short);

    		if(keyboard.left.isDown){
    			short.body.velocity.x=-0.50;
    			stick.body.velocity.x=-0.50;

    			short.animations.play('left');
    			stick.animations.play('left');
    		}
    		else if (keyboard.right.isDown){
    			short.body.velocity.x=-0.50;
    			stick.body.velocity.x=-0.50;

    			short.animations.play('right');
    			stick.animations.play('right');
    		}
    		else{
    			short.body.velocity.y=0;
    			short.body.velocity.x=0;

    			stick.body.velocity.y=0;
    			stick.body.velocity.x=0;

    			short.animations.stop();
    			stick.animations.stop();
    		}
    		if(keyboard.up.isDown&& player.touching.down){
    			short.body.velocity.y=1;
    			stick.body.velocity.y=1;
    		}
    	},    	
    }
    game.state.add("playgame", characterGame,true);

    	var gamePlay=function(){
    		"use strict";
    		return{

    		}
    	}();