Syatong.Game = function(game){
	//this._player = null;
	this._fontStyle = null;
	this.music = null;
	Syatong._scoreText = null;
	Syatong._lifeText = 3;

};
Syatong.Game.prototype = {
	create: function(){
		// start the physics engine
		this.physics.startSystem(Phaser.Physics.ARCADE);
		this.add.sprite(0, 0, 'wallpaper');

        back = game.add.sprite(13,10,"back");

        short = game.add.sprite(78,220,'short');
        stick = game.add.sprite(220,220,'stick');

        short.animations.add('walk-right',[5,6,7],7,true);
        short.animations.add('walk-left',[0,1,2,3],7,true);

        stick.animations.add('walk-right',[7,8,9,10],7,true);
        stick.animations.add('walk-left',[3,4,5],7,true);
		//this.add.sprite(20,550, 'score');
		//this.add.sprite(450, 550, 'best');
		//this.add.sprite(220, 220, 'trash');
		this.music = this.add.audio('music');
		this.music.loop = true;
		this.music.play();
		// add pause button
		this.add.button(Syatong.GAME_WIDTH-96-10, 5, 'button-pause', this.managePause, this);
		this._fontStyle = { font: "40px Arial", fill: "yellow", stroke: "#333", strokeThickness: 5, align: "center" };
		// initialize the score text with 0
		Syatong._scoreText = this.add.text(80, 50, "0", this._fontStyle);
		Syatong._lifeText = this.add.text(80, 120, ""+localStorage.getItem("Life"), this._fontStyle);
},

	managePause: function(){
		// pause the game
		this.game.paused = true;
		// add proper informational text
		var pausedText = this.add.text(100, 250, "Paused.\nTap anywhere to continue.", this._fontStyle);
		// set event listener for the user's click/tap the screen
		this.input.onDown.add(function(){
			// remove the pause text
			pausedText.destroy();
			// unpause the game
			this.game.paused = false;
		}, this);
	},
};