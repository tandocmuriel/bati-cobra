Syatong.Preloader = function(game){
	// define width and height of the game
	Syatong.GAME_WIDTH = 640;
	Syatong.GAME_HEIGHT = 960;
};
Syatong.Preloader.prototype = {
	preload: function(){
		// load images
		
// var hoop,
//  	left_rim,
//  	right_rim,
//  	paper,
//  	front_rim,
//  	score = 0,
//  	score_text,
//  	high_score = 0,
//  	high_score_text,
//  	best_text;

// var score_sound,
// 		backboard,
// 		whoosh,
// 		fail,
// 		spawn;

// var moveInTween,
// 		fadeInTween,
// 		moveOutTween,
// 		fadeOutTween,
// 		emoji,
// 		emojiName;

var collisionGroup;

		this.load.image('background', 'img/bg-start.png');
		this.load.image('wallpaper', 'img/bg.png');
		this.load.image('button-play', 'img/play.png', 401, 140);
		this.load.image('back', 'img/arrow.png');
		// this.load.image('score-bg', 'img/score-bg.png');
		this.load.image('short', 'img/short.png',170,167);
		this.load.image('stick', 'img/stick.png',200,300);

	},

	create: function(){
		// start the MainMenu state
		this.state.start('MainMenu');
	},
};